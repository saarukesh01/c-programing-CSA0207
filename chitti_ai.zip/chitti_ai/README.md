# Chitti AI

A ChatGPT-style chat web app powered by **Google Gemini 3.8 Flash**.

## Requirements
- Python 3.10 or newer
- Internet connection
- Gemini API key from Google AI Studio: https://aistudio.google.com/apikey

## Run in Antigravity

1. Extract `chitti_ai.zip`.
2. Open the extracted `chitti_ai` folder in Antigravity.
3. Open the integrated terminal in that folder.
4. Create and activate a virtual environment (optional but recommended):

   **Windows**
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

   **macOS / Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

5. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
6. Copy `.env.example` to a new file named `.env`.
7. Open `.env` and replace `PASTE_YOUR_GEMINI_API_KEY_HERE` with your own key.
8. Start Chitti:
   ```bash
   python app.py
   ```
9. Open this address in your browser: http://127.0.0.1:5000

## Features
- Chitti assistant branding and responsive chat interface
- Gemini-powered answers with conversation context
- Markdown and formatted code responses
- Suggested starter prompts
- New chat button
- API key kept on the Python server (not exposed in browser code)

## Configuration
Edit `.env`:
- `GEMINI_API_KEY`: your private Gemini API key
- `GEMINI_MODEL`: defaults to `gemini-3.8-flash`
- `PORT`: defaults to `5000`

Do not upload or share your `.env` file. Do not paste your API key into frontend JavaScript or public repositories.

## Troubleshooting
- **API key missing:** make sure the file is named `.env` (not `.env.txt`) and restart `python app.py`.
- **Invalid key / permission error:** create or check your key in Google AI Studio.
- **Model not found:** check the current model ID and your API access; update `GEMINI_MODEL` in `.env`.
- **Port busy:** set `PORT=5001` in `.env`, restart, then open http://127.0.0.1:5001.

Chitti is an independent demo application and is not ChatGPT or an OpenAI product.
