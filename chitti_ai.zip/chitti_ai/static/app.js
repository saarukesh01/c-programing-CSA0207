const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const sendButton = document.getElementById("sendButton");
const messagesEl = document.getElementById("messages");
const welcome = document.getElementById("welcome");
const chatArea = document.getElementById("chatArea");
const history = [];
let busy = false;

function scrollDown(){ chatArea.scrollTop = chatArea.scrollHeight; }

function addMessage(role, content, isTyping=false){
  const row = document.createElement("div");
  row.className = `message ${role === "user" ? "user" : "assistant"}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "You" : "✦";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if(isTyping){
    bubble.innerHTML = '<div class="typing"><i></i><i></i><i></i></div>';
    row.id = "typingRow";
  } else if(role === "user") {
    bubble.textContent = content;
  } else {
    const html = window.marked ? marked.parse(content) : content.replace(/</g,"&lt;").replace(/>/g,"&gt;");
    bubble.innerHTML = window.DOMPurify ? DOMPurify.sanitize(html) : html;
  }
  row.append(avatar,bubble);
  messagesEl.appendChild(row);
  scrollDown();
  return row;
}

async function sendMessage(text){
  text = text.trim();
  if(!text || busy) return;
  busy = true; sendButton.disabled = true;
  welcome.style.display = "none";
  addMessage("user", text);
  history.push({role:"user",content:text});
  const typing = addMessage("model","",true);
  input.value = ""; input.style.height = "auto";
  try{
    const response = await fetch("/api/chat",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({messages:history})
    });
    const data = await response.json();
    typing.remove();
    if(!response.ok) throw new Error(data.error || "Something went wrong.");
    history.push({role:"model",content:data.reply});
    addMessage("model",data.reply);
  }catch(error){
    typing.remove();
    addMessage("model",`**Chitti couldn't reply:** ${error.message}`);
  }finally{
    busy = false; sendButton.disabled = false; input.focus();
  }
}

form.addEventListener("submit",e=>{e.preventDefault();sendMessage(input.value);});
input.addEventListener("input",()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,160)+"px";});
input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
document.querySelectorAll(".suggestion").forEach(btn=>btn.addEventListener("click",()=>sendMessage(btn.dataset.prompt)));
document.getElementById("newChat").addEventListener("click",()=>{
  history.length=0; messagesEl.innerHTML=""; welcome.style.display="block"; input.focus();
});
fetch("/api/status").then(r=>r.json()).then(s=>{
  const dot=document.getElementById("statusDot");
  const label=document.getElementById("statusText");
  if(s.configured){dot.classList.add("ready");label.textContent="AI ready";}
  else{label.textContent="API key needed";}
}).catch(()=>{document.getElementById("statusText").textContent="Server offline";});
