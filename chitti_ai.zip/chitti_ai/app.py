import os
import requests
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)

API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash").strip()
SYSTEM_PROMPT = """You are Chitti, a helpful, friendly, intelligent AI assistant.
Answer accurately and clearly like a capable general-purpose assistant.
Use the user's language when practical. Explain difficult topics step by step.
If you are unsure, say so rather than inventing facts. Format code in fenced code blocks.
You are Chitti; do not claim to be ChatGPT or another AI product."""

@app.get("/")
def home():
    return render_template("index.html", model=MODEL)

@app.get("/api/status")
def status():
    return jsonify({"configured": bool(API_KEY), "model": MODEL})

@app.post("/api/chat")
def chat():
    if not API_KEY:
        return jsonify({"error": "Gemini API key is missing. Add GEMINI_API_KEY to your .env file and restart Chitti."}), 503

    data = request.get_json(silent=True) or {}
    messages = data.get("messages", [])
    if not isinstance(messages, list) or not messages:
        return jsonify({"error": "Please enter a message."}), 400

    contents = []
    # Keep the most recent 24 messages; accept only plain text user/model turns.
    for item in messages[-24:]:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        content = item.get("content")
        if role not in ("user", "model") or not isinstance(content, str):
            continue
        content = content.strip()[:12000]
        if content:
            contents.append({"role": role, "parts": [{"text": content}]})

    if not contents or contents[-1]["role"] != "user":
        return jsonify({"error": "The latest message must be from the user."}), 400

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent"
    payload = {
        "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": contents,
        "generationConfig": {
            "temperature": 0.7,
            "topP": 0.95,
            "maxOutputTokens": 4096
        }
    }

    try:
        response = requests.post(
            url,
            headers={"x-goog-api-key": API_KEY, "Content-Type": "application/json"},
            json=payload,
            timeout=90
        )
        result = response.json()
        if not response.ok:
            message = result.get("error", {}).get("message", "Gemini API request failed.")
            return jsonify({"error": message}), response.status_code

        answer = "".join(
            part.get("text", "")
            for candidate in result.get("candidates", [])
            for part in candidate.get("content", {}).get("parts", [])
            if isinstance(part, dict)
        ).strip()

        if not answer:
            return jsonify({"error": "The model returned an empty response. Please try again."}), 502
        return jsonify({"reply": answer, "model": MODEL})
    except requests.Timeout:
        return jsonify({"error": "The AI request timed out. Please try again."}), 504
    except requests.RequestException as exc:
        return jsonify({"error": f"Could not connect to Gemini: {exc}"}), 502
    except ValueError:
        return jsonify({"error": "Gemini returned an unreadable response."}), 502

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=True)
